Pho
To
Nium.exe
------------------
   made by xuepiao (aka compaq deskpro2000)
7playload and sound only 
:)

mbr memoxide by williamP???